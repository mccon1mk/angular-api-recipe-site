export const userCreds = {
    userID: '46e0f808',
    userKey: 'b5d958b3e676ffad7efba7bceedbd63b'
};